This file must be deleted by the post-create script.
