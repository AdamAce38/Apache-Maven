groupId=${groupId}
artifactId=${artifactId}
version=${version}
package=${package}